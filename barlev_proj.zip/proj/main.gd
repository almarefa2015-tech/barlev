extends Control
# اقتحم خط بارليف — نسخة تجريبية (3 نقاط)

const W := 1280.0
const H := 720.0
const STAGES := ["p1", "walk", "crate1", "walk", "p2", "walk", "crate2", "walk", "p3", "end"]

class Enemy:
	var kind := ""
	var node: Sprite2D
	var hp := 3.0
	var s := 0.5
	var lane := 0.0
	var anim := "fire"
	var fi := 0.0
	var dead := false
	var t := 0.0
	var next_shot := 2.0
	var spd := 0.0
	var thrown := false
	var fade := 1.0
	var done := false

var F := {}
var SND := {}
var used_cache := {}
var bg: TextureRect
var world: Node2D
var wp: TextureRect
var wp_tex := {}
var flash: ColorRect
var hpfill: ColorRect
var ammo_l: Label
var msg_l: Label
var sub_l: Label
var stage_l: Label
var go_btn: Button
var retry_btn: Button
var start_btn: Button
var title_l: Label
var wbtns := {}
var crate: Sprite2D
var heat_bar: ColorRect
var hint: Label
var font: Font

var hp := 100.0
var enemies: Array = []
var stage := -1
var st := 0.0
var spawned := {}
var cur := "ak"
var have := {"ak": true, "rpg": false, "sniper": false, "grenade": false, "mortar": false}
var ammo := {"ak": 30, "rpg": 0, "sniper": 5, "grenade": 0, "mortar": 0}
var cd := 0.0
var reload_t := 0.0
var heat := 0.0
var over_heat := 0.0
var walking := false
var walk_t := 0.0
var down := false
var mpos := Vector2.ZERO
var playing := false
var shake := 0.0
var tank: Enemy = null
var tank_shot := 4.0
var dead_flag := false
var ending := false
var rpg_msgs := 0
var wp_kick := 0.0
var players: Array = []

func _ready() -> void:
	font = load("res://assets/font/dv.ttf")
	var th := Theme.new()
	th.default_font = font
	th.default_font_size = 26
	theme = th
	bg = TextureRect.new()
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_SCALE
	bg.size = Vector2(W, H)
	bg.texture = load("res://assets/bg/trench1.jpg")
	add_child(bg)
	world = Node2D.new()
	add_child(world)
	wp = TextureRect.new()
	wp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	wp.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	wp.stretch_mode = TextureRect.STRETCH_SCALE
	add_child(wp)
	wp.z_index = 350
	flash = ColorRect.new()
	flash.color = Color(0.8, 0, 0, 0)
	flash.size = Vector2(W, H)
	flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(flash)
	_build_hud()
	for n in ["shot", "mg", "rpg", "boom", "hit", "hurt", "click", "pick"]:
		SND[n] = load("res://assets/snd/%s.wav" % n)
	for i in 6:
		var p := AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	for n in ["ak", "rpg", "sniper", "grenade", "mortar"]:
		wp_tex[n] = load("res://assets/wp/%s.png" % n)
	title_l.text = "جاري التحميل..."
	start_btn.visible = false
	await get_tree().process_frame
	await get_tree().process_frame
	for name in ["fire", "adv", "gren", "die", "tank"]:
		var arr: Array = []
		for i in 64:
			arr.append(load("res://assets/en/%s%02d.png" % [name, i]))
		F[name] = arr
	F["walk"] = []
	for i in 80:
		F["walk"].append(load("res://assets/walk/w%03d.jpg" % i))
	crate = Sprite2D.new()
	crate.texture = load("res://assets/en/crate.png")
	crate.centered = false
	crate.visible = false
	world.add_child(crate)
	title_l.text = "اقتحم خط بارليف\nنسخة تجريبية — 3 نقاط"
	start_btn.visible = true

func _label(txt: String, size: int, col: Color, pos: Vector2, w: float, align := HORIZONTAL_ALIGNMENT_CENTER) -> Label:
	var l := Label.new()
	l.text = txt
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 8)
	l.position = pos
	l.size = Vector2(w, 10)
	l.horizontal_alignment = align
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(l)
	return l

func _btn(txt: String, pos: Vector2, sz: Vector2, size := 30) -> Button:
	var b := Button.new()
	b.text = txt
	b.position = pos
	b.size = sz
	b.add_theme_font_size_override("font_size", size)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.1, 0.12, 0.08, 0.85)
	sb.border_color = Color(0.85, 0.7, 0.2)
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(12)
	b.add_theme_stylebox_override("normal", sb)
	var sb2 := sb.duplicate()
	sb2.bg_color = Color(0.35, 0.3, 0.1, 0.95)
	b.add_theme_stylebox_override("pressed", sb2)
	b.add_theme_stylebox_override("hover", sb)
	b.add_theme_color_override("font_color", Color(1, 0.92, 0.6))
	add_child(b)
	return b

func _build_hud() -> void:
	var back := ColorRect.new()
	back.color = Color(0, 0, 0, 0.6)
	back.position = Vector2(20, 18)
	back.size = Vector2(304, 26)
	back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(back)
	hpfill = ColorRect.new()
	hpfill.color = Color(0.2, 0.75, 0.25)
	hpfill.position = Vector2(22, 20)
	hpfill.size = Vector2(300, 22)
	hpfill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(hpfill)
	heat_bar = ColorRect.new()
	heat_bar.color = Color(1, 0.5, 0.1)
	heat_bar.position = Vector2(22, 50)
	heat_bar.size = Vector2(0, 10)
	heat_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(heat_bar)
	stage_l = _label("", 26, Color(1, 0.9, 0.5), Vector2(W - 320, 14), 300, HORIZONTAL_ALIGNMENT_RIGHT)
	ammo_l = _label("", 30, Color.WHITE, Vector2(W - 360, H - 52), 340, HORIZONTAL_ALIGNMENT_RIGHT)
	msg_l = _label("", 46, Color(1, 0.95, 0.6), Vector2(100, 80), W - 200)
	sub_l = _label("", 32, Color(1, 1, 1), Vector2(100, 150), W - 200)
	hint = _label("", 28, Color(1, 0.85, 0.3), Vector2(100, H - 170), W - 200)
	var x := 20.0
	for n in ["ak", "sniper", "grenade", "rpg", "mortar"]:
		var b := _btn({"ak": "AK", "sniper": "قناصة", "grenade": "قنبلة", "rpg": "RPG", "mortar": "هاون"}[n], Vector2(x, H - 86), Vector2(130, 66), 28)
		b.pressed.connect(_select.bind(n))
		b.visible = false
		wbtns[n] = b
		x += 140
	go_btn = _btn("تقدّم  ◀", Vector2(W / 2 - 150, H - 150), Vector2(300, 90), 40)
	go_btn.visible = false
	go_btn.pressed.connect(_on_go)
	retry_btn = _btn("إعادة المحاولة", Vector2(W / 2 - 170, 380), Vector2(340, 90), 38)
	retry_btn.visible = false
	retry_btn.pressed.connect(_retry)
	var dim := ColorRect.new()
	title_l = _label("", 64, Color(1, 0.88, 0.45), Vector2(60, 180), W - 120)
	start_btn = _btn("ابدأ", Vector2(W / 2 - 150, 430), Vector2(300, 100), 48)
	start_btn.pressed.connect(_start_game)
	for c in get_children():
		if c is Control and c != bg:
			c.z_index = 400

func play(n: String, vol := 0.0) -> void:
	for p in players:
		if not p.playing:
			p.stream = SND[n]
			p.volume_db = vol
			p.play()
			return

func _start_game() -> void:
	title_l.text = ""
	start_btn.visible = false
	playing = true
	hp = 100.0
	stage = -1
	_next_stage()

func _next_stage() -> void:
	stage += 1
	st = 0.0
	spawned = {}
	_clear_enemies()
	crate.visible = false
	go_btn.visible = false
	msg_l.text = ""
	sub_l.text = ""
	hint.text = ""
	walking = false
	var s: String = STAGES[stage]
	var pi := 0
	for i in range(stage + 1):
		if STAGES[i].begins_with("p"):
			pi += 1
	match s:
		"p1":
			cur = "mg"
			bg.texture = load("res://assets/bg/trench2.jpg")
			msg_l.text = "نقطة 1 — الرشاش الثابت"
			hint.text = "اضغط مع الاستمرار على العدو للإطلاق"
		"walk":
			walking = true
			walk_t = 0.0
			msg_l.text = ""
		"crate1":
			bg.texture = load("res://assets/bg/trench1.jpg")
			_place_crate()
			msg_l.text = "صندوق ذخيرة"
			hint.text = "اضغط على الصندوق"
		"crate2":
			bg.texture = load("res://assets/bg/trench2.jpg")
			_place_crate()
			msg_l.text = "صندوق ذخيرة"
			hint.text = "اضغط على الصندوق"
		"p2":
			bg.texture = load("res://assets/bg/trench1.jpg")
		"p3":
			bg.texture = load("res://assets/bg/trench2.jpg")
			msg_l.text = "نقطة 3 — موقع محصّن + دبابة"
		"end":
			ending = true
			msg_l.text = "انتهت النسخة التجريبية 🎖"
			sub_l.text = "لو عجبتك اللعبة قيّمها وقولّي رأيك\nعشان نكمل باقي المراحل والهاون"
			retry_btn.text = "العب تاني"
			retry_btn.visible = true
	_select_default()
	_update_hud()

func _select_default() -> void:
	var s: String = STAGES[stage] if stage >= 0 else "p1"
	if s == "p1":
		cur = "mg"
	elif cur == "mg":
		cur = "ak"
	_select(cur)

func _place_crate() -> void:
	crate.visible = true
	crate.scale = Vector2(1.1, 1.1)
	crate.position = Vector2(W * 0.48 - 150, H * 0.84 - 180)

func _select(n: String) -> void:
	if n == "mg":
		cur = "mg"
	elif have.get(n, false):
		cur = n
	for k in wbtns:
		wbtns[k].visible = have[k] and STAGES[max(stage, 0)] != "p1" and playing and not ending
		wbtns[k].modulate = Color(1, 1, 0.4) if k == cur else Color.WHITE
	var tn: String = "ak" if cur == "mg" else cur
	wp.texture = wp_tex[tn]
	var sz: Vector2 = wp_tex[tn].get_size() * (1.1 if tn == "mortar" else 0.8)
	wp.size = sz
	wp_base()
	_update_hud()

var wp_pos := Vector2.ZERO
func wp_base() -> void:
	wp_pos = Vector2(W - wp.size.x - 10, H - wp.size.y + 40)
	if cur == "mortar":
		wp_pos = Vector2(W * 0.5 - wp.size.x * 0.5 + 100, H - wp.size.y + 30)
	if cur == "grenade":
		wp_pos = Vector2(W - wp.size.x - 120, H - wp.size.y + 80)
	wp.position = wp_pos

func _update_hud() -> void:
	hpfill.size.x = 300.0 * clampf(hp / 100.0, 0, 1)
	hpfill.color = Color(0.2, 0.75, 0.25) if hp > 40 else Color(0.85, 0.2, 0.15)
	var s: String = STAGES[max(stage, 0)]
	var pn := 0
	for i in range(max(stage, 0) + 1):
		if STAGES[i].begins_with("p"):
			pn += 1
	stage_l.text = "نقطة %d/3" % clampi(pn, 1, 3)
	match cur:
		"mg": ammo_l.text = "رشاش ثابت  ∞"
		"ak": ammo_l.text = ("AK  إعادة تعبئة..." if reload_t > 0 else "AK  %d" % ammo["ak"])
		"sniper": ammo_l.text = "قناصة  %d" % ammo["sniper"]
		"grenade": ammo_l.text = "قنابل  %d" % ammo["grenade"]
		"rpg": ammo_l.text = "RPG  %d" % ammo["rpg"]
		"mortar": ammo_l.text = "هاون  %d" % ammo["mortar"]

func _on_go() -> void:
	go_btn.visible = false
	_next_stage()

func _retry() -> void:
	retry_btn.visible = false
	msg_l.text = ""
	sub_l.text = ""
	if ending:
		ending = false
		have = {"ak": true, "rpg": false, "sniper": false, "grenade": false, "mortar": false}
		ammo = {"ak": 30, "rpg": 0, "sniper": 5, "grenade": 0, "mortar": 0}
		hp = 100.0
		stage = -1
		_next_stage()
		return
	dead_flag = false
	hp = 100.0
	# restart current point
	stage -= 1
	_next_stage()

func _clear_enemies() -> void:
	for e in enemies:
		e.node.queue_free()
	enemies.clear()
	tank = null

# ---------- enemies ----------
func spawn(kind: String, lane: float, s: float) -> Enemy:
	var e := Enemy.new()
	e.kind = kind
	e.lane = lane
	e.s = s
	e.node = Sprite2D.new()
	e.node.centered = false
	world.add_child(e.node)
	match kind:
		"rifle":
			e.anim = "fire"; e.hp = 3.0; e.next_shot = randf_range(1.2, 3.0)
		"runner":
			e.anim = "adv"; e.hp = 2.0; e.spd = randf_range(0.075, 0.1); e.s = minf(s, 0.4)
		"gren":
			e.anim = "gren"; e.hp = 2.0
		"tank":
			e.anim = "tank"; e.hp = 99.0
			tank = e
			tank_shot = 7.5
	e.fi = 0.0
	enemies.append(e)
	_pose(e)
	return e

func _frames(e: Enemy) -> Array:
	return F[e.anim]

func _pose(e: Enemy) -> void:
	var arr := _frames(e)
	var idx := clampi(int(e.fi), 0, arr.size() - 1)
	var tex: Texture2D = arr[idx]
	e.node.texture = tex
	var ts := tex.get_size()
	if e.kind == "tank":
		e.node.offset = Vector2(-ts.x / 2.0, -ts.y)
		e.node.scale = Vector2(1.4, 1.4)
		e.node.position = Vector2(W * 0.64, H * 0.9)
		e.node.z_index = 60
	else:
		e.node.offset = Vector2(-ts.x / 2.0, -ts.y)
		var sc := e.s * 1.7
		e.node.scale = Vector2(sc, sc)
		var gy := H * 0.5 + H * 0.42 * e.s
		e.node.position = Vector2(W * 0.5 + e.lane * W * 0.5 * e.s, gy)
		e.node.z_index = int(e.s * 100)
	e.node.modulate.a = e.fade

func _rect(e: Enemy) -> Rect2:
	var tex: Texture2D = e.node.texture
	var id := tex.get_instance_id()
	if not used_cache.has(id):
		used_cache[id] = tex.get_image().get_used_rect()
	var r: Rect2i = used_cache[id]
	var sc: Vector2 = e.node.scale
	var ts := tex.get_size()
	var org: Vector2 = e.node.position + Vector2(-ts.x / 2.0, -ts.y) * sc
	return Rect2(org + Vector2(r.position) * sc, Vector2(r.size) * sc)

func _kill(e: Enemy) -> void:
	e.dead = true
	e.anim = "die"
	e.fi = 14.0
	e.t = 0.0
	play("hit")

func _damage(e: Enemy, dmg: float) -> void:
	if e.dead or e.kind == "tank":
		return
	e.hp -= dmg
	if e.hp <= 0.0:
		_kill(e)

func _hurt(d: float) -> void:
	if dead_flag or ending:
		return
	hp -= d
	flash.color.a = 0.45
	shake = 0.25
	play("hurt")
	_update_hud()
	if hp <= 0.0:
		hp = 0.0
		_update_hud()
		dead_flag = true
		msg_l.text = "استُشهدت!"
		sub_l.text = "جرّب النقطة دي تاني"
		retry_btn.text = "إعادة المحاولة"
		retry_btn.visible = true

func _tracer(a: Vector2, b: Vector2, col := Color(1, 0.9, 0.5)) -> void:
	var l := Line2D.new()
	l.width = 4.0
	l.default_color = col
	l.add_point(a)
	l.add_point(b)
	l.z_index = 200
	world.add_child(l)
	var tw := create_tween()
	tw.tween_property(l, "modulate:a", 0.0, 0.1)
	tw.tween_callback(l.queue_free)

func _boom(p: Vector2, size := 1.0) -> void:
	var c := CPUParticles2D.new()
	c.position = p
	c.emitting = true
	c.one_shot = true
	c.amount = int(40 * size)
	c.lifetime = 0.7
	c.explosiveness = 1.0
	c.spread = 180.0
	c.initial_velocity_min = 120.0 * size
	c.initial_velocity_max = 380.0 * size
	c.gravity = Vector2(0, 220)
	c.scale_amount_min = 6.0 * size
	c.scale_amount_max = 16.0 * size
	c.color = Color(1, 0.6, 0.15)
	c.z_index = 300
	world.add_child(c)
	var t := get_tree().create_timer(1.2)
	t.timeout.connect(c.queue_free)
	shake = 0.4 * size
	play("boom", -2.0)

# ---------- shooting ----------
func _fire() -> void:
	if not playing or dead_flag or ending or walking:
		return
	if cd > 0.0 or reload_t > 0.0 or over_heat > 0.0:
		return
	if STAGES[stage] == "crate1" or STAGES[stage] == "crate2":
		return
	var p := mpos
	if p.y > H - 100.0 and p.x < 620.0:
		return
	var muzzle := Vector2(W * 0.78, H * 0.78)
	match cur:
		"mg":
			cd = 0.075
			heat += 0.035
			if heat >= 1.0:
				over_heat = 2.2
				hint.text = "الماسورة سخنت! استنى..."
			play("mg", -6.0)
			_hitscan(p, 1.2, muzzle)
			wp_kick = 14.0
		"ak":
			if ammo["ak"] <= 0:
				reload_t = 1.3
				play("click")
				return
			ammo["ak"] -= 1
			cd = 0.13
			play("shot", -4.0)
			_hitscan(p, 1.0, muzzle)
			wp_kick = 18.0
			if ammo["ak"] <= 0:
				reload_t = 1.3
				play("click")
		"sniper":
			if ammo["sniper"] <= 0:
				hint.text = "القناصة فاضية — استخدم AK"
				cd = 0.5
				return
			ammo["sniper"] -= 1
			cd = 1.0
			play("shot", 2.0)
			_hitscan(p, 6.0, muzzle)
			wp_kick = 40.0
		"rpg":
			if ammo["rpg"] <= 0:
				return
			ammo["rpg"] -= 1
			cd = 1.6
			play("rpg", 0.0)
			wp_kick = 50.0
			_rpg(p, muzzle)
		"mortar":
			if ammo["mortar"] <= 0:
				return
			ammo["mortar"] -= 1
			cd = 2.0
			play("rpg", -4.0)
			wp_kick = 60.0
			_mortar(p)
		"grenade":
			if ammo["grenade"] <= 0:
				return
			ammo["grenade"] -= 1
			cd = 1.2
			play("click")
			wp_kick = 30.0
			_grenade(p)
	_update_hud()

func _top_enemy_at(p: Vector2) -> Enemy:
	var best: Enemy = null
	for e in enemies:
		if e.dead or e.fade < 1.0:
			continue
		if _rect(e).has_point(p):
			if best == null or e.node.z_index > best.node.z_index:
				best = e
	return best

func _hitscan(p: Vector2, dmg: float, muzzle: Vector2) -> void:
	_tracer(muzzle, p)
	var e := _top_enemy_at(p)
	if e == null:
		return
	if e.kind == "tank":
		_tracer(p, p + Vector2(randf_range(-30, 30), -30), Color(1, 1, 1))
		if hint.text == "" or randf() < 0.05:
			hint.text = "الرصاص ما بيأثرش في الدبابة — استخدم RPG"
		return
	var r := _rect(e)
	var head := p.y < r.position.y + r.size.y * 0.25
	_damage(e, dmg * (3.0 if head else 1.0))

func _rpg(p: Vector2, muzzle: Vector2) -> void:
	_tracer(muzzle, p, Color(1, 0.7, 0.3))
	await get_tree().create_timer(0.25).timeout
	if tank != null and not tank.dead and not tank.done:
		var r := _rect(tank)
		var weak := Rect2(r.position + Vector2(r.size.x * 0.22, r.size.y * 0.30), Vector2(r.size.x * 0.56, r.size.y * 0.28))
		if weak.has_point(p):
			_boom(p, 2.0)
			_boom(r.position + r.size * 0.5, 2.4)
			tank.dead = true
			tank.fade = 0.99
			msg_l.text = "دبابة اتدمّرت!"
			hint.text = ""
			return
		elif r.has_point(p):
			_boom(p, 0.8)
			hint.text = "ماأثرتش! اضرب بين البرج والبدن"
			rpg_msgs += 1
			_check_rpg_refill()
			return
	_boom(p, 1.2)
	for e in enemies:
		if not e.dead and e.kind != "tank" and _rect(e).grow(40.0).has_point(p):
			_damage(e, 8.0)
	_check_rpg_refill()

func _check_rpg_refill() -> void:
	if ammo["rpg"] <= 0 and tank != null and not tank.dead:
		ammo["rpg"] = 2
		hint.text = "لقيت صاروخين تانيين! اضرب بين البرج والبدن"
		_update_hud()

func _mortar(p: Vector2) -> void:
	hint.text = "القذيفة في الطريق..."
	await get_tree().create_timer(1.6).timeout
	hint.text = ""
	_boom(p, 2.2)
	for e in enemies:
		if e.dead or e.kind == "tank":
			continue
		var c := _rect(e).get_center()
		if c.distance_to(p) < 260.0 * maxf(e.s, 0.6):
			_damage(e, 10.0)

func _grenade(p: Vector2) -> void:
	await get_tree().create_timer(0.5).timeout
	_boom(p, 1.5)
	for e in enemies:
		if e.dead or e.kind == "tank":
			continue
		var c := _rect(e).get_center()
		if c.distance_to(p) < 190.0 * maxf(e.s, 0.6):
			_damage(e, 8.0)

# ---------- input ----------
func _unhandled_input(ev: InputEvent) -> void:
	if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
		down = ev.pressed
		mpos = ev.position
		if ev.pressed:
			_tap(ev.position)
	elif ev is InputEventMouseMotion:
		mpos = ev.position

func _tap(p: Vector2) -> void:
	var s: String = STAGES[stage] if stage >= 0 else ""
	if (s == "crate1" or s == "crate2") and crate.visible:
		var r := Rect2(crate.position, crate.texture.get_size() * crate.scale).grow(60.0)
		if r.has_point(p):
			_open_crate(s)

func _open_crate(s: String) -> void:
	crate.visible = false
	play("pick")
	if s == "crate1":
		have["sniper"] = true
		have["grenade"] = true
		have["mortar"] = true
		ammo["mortar"] = 6
		ammo["sniper"] = 5
		ammo["grenade"] = 4
		msg_l.text = "قناصة + 4 قنابل + هاون!"
		sub_l.text = "الهاون للمواقع البعيدة المحصّنة — غيّر السلاح من الأزرار"
	else:
		have["rpg"] = true
		ammo["rpg"] = 3
		msg_l.text = "RPG — 3 صواريخ!"
		sub_l.text = "الدبابات: اضرب بين البرج والبدن بس"
	hint.text = ""
	_select_default()
	for k in wbtns:
		wbtns[k].visible = have[k]
	go_btn.visible = true

# ---------- loop ----------
func _process(dt: float) -> void:
	if not playing:
		return
	st += dt
	cd = maxf(cd - dt, 0.0)
	if flash.color.a > 0.0:
		flash.color.a = maxf(flash.color.a - dt * 1.2, 0.0)
	if reload_t > 0.0:
		reload_t -= dt
		if reload_t <= 0.0:
			ammo["ak"] = 30
			_update_hud()
	if over_heat > 0.0:
		over_heat -= dt
		heat = maxf(heat - dt * 0.5, 0.0)
		if over_heat <= 0.0:
			hint.text = ""
			heat = 0.0
	else:
		heat = maxf(heat - dt * 0.28, 0.0)
	heat_bar.size.x = 300.0 * heat if cur == "mg" else 0.0
	heat_bar.color = Color(1, 0.2, 0.1) if over_heat > 0.0 else Color(1, 0.6, 0.1)
	if shake > 0.0:
		shake = maxf(shake - dt, 0.0)
		position = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * 24.0
	else:
		position = Vector2.ZERO
	wp_kick = lerpf(wp_kick, 0.0, minf(dt * 14.0, 1.0))
	wp.position = wp_pos + Vector2(wp_kick * 0.5, wp_kick)
	if down and (cur == "mg" or cur == "ak"):
		_fire()
	elif down and cd <= 0.0 and (cur == "sniper" or cur == "rpg" or cur == "grenade" or cur == "mortar"):
		_fire()
		down = false
	if dead_flag or ending:
		_tick_enemies(dt, false)
		return
	_tick_enemies(dt, true)
	match STAGES[stage]:
		"walk": _tick_walk(dt)
		"p1": _tick_p1()
		"p2": _tick_p2()
		"p3": _tick_p3()

func _tick_walk(dt: float) -> void:
	walk_t += dt
	var fi := int(walk_t * 10.0)
	var n := 55
	if fi >= n:
		_next_stage()
		return
	bg.texture = F["walk"][clampi(fi, 0, 79)]

func _alive() -> int:
	var c := 0
	for e in enemies:
		if not e.done and (not e.dead or e.kind == "tank") :
			c += 1
	return c

func _at(key: String, t: float) -> bool:
	if st >= t and not spawned.has(key):
		spawned[key] = true
		return true
	return false

func _stage_clear() -> void:
	if go_btn.visible:
		return
	msg_l.text = "النقطة اتأمّنت ✔"
	hint.text = ""
	go_btn.visible = true

func _tick_p1() -> void:
	if st > 4.0 and msg_l.text.begins_with("نقطة"):
		msg_l.text = ""
	if st > 7.0 and hint.text.begins_with("اضغط"):
		hint.text = ""
	if _at("a", 1.5):
		spawn("runner", -0.2, 0.35); spawn("runner", 0.18, 0.35)
	if _at("b", 4.5):
		spawn("rifle", -0.35, 0.5); spawn("rifle", 0.35, 0.45)
	if _at("c", 10.0):
		spawn("runner", -0.3, 0.35); spawn("runner", 0.0, 0.35); spawn("runner", 0.3, 0.35)
	if _at("d", 15.0):
		spawn("rifle", -0.3, 0.55); spawn("rifle", 0.2, 0.5); spawn("gren", 0.0, 0.42)
	if _at("e", 22.0):
		for i in 4:
			var e := spawn("runner", -0.35 + i * 0.23, 0.35)
			e.spd += i * 0.004
	if st > 26.0 and spawned.has("e") and _alive() == 0:
		_stage_clear()

var shouts := [["!עצרו", "قفوا!"], ["!אש", "نار!"], ["!הם כאן", "هم هنا!"], ["!תפסו אותו", "امسكوه!"]]
func _tick_p2() -> void:
	if _at("m0", 0.3):
		msg_l.text = "نقطة 2 — كمين!"
		sub_l.text = ""
	if st > 1.8 and not spawned.has("sh0"):
		spawned["sh0"] = true
		_shout(0)
	if st > 3.0 and not spawned.has("sh1"):
		spawned["sh1"] = true
		_shout(1)
	if _at("a", 3.3):
		spawn("rifle", -0.38, 0.75); spawn("rifle", 0.4, 0.75); spawn("runner", 0.0, 0.4)
	if _at("sh2", 4.5):
		_shout(2)
	if _at("b", 6.0):
		spawn("gren", 0.2, 0.6); spawn("rifle", -0.05, 0.9)
	if _at("sh3", 8.0):
		_shout(3)
	if _at("c", 8.5):
		spawn("runner", -0.3, 0.35); spawn("runner", 0.32, 0.35); spawn("runner", 0.0, 0.35)
	if st > 12.0 and spawned.has("c") and _alive() == 0:
		sub_l.text = ""
		_stage_clear()

func _shout(i: int) -> void:
	msg_l.text = shouts[i][0]
	sub_l.text = "«%s»" % shouts[i][1]
	msg_l.add_theme_color_override("font_color", Color(1, 0.35, 0.3))
	var tw := create_tween()
	tw.tween_interval(1.4)
	tw.tween_callback(func():
		if msg_l.text == shouts[i][0]:
			msg_l.text = ""
			sub_l.text = ""
		msg_l.add_theme_color_override("font_color", Color(1, 0.95, 0.6)))

func _tick_p3() -> void:
	if st > 4.0 and msg_l.text.begins_with("نقطة"):
		msg_l.text = ""
	if _at("a", 0.8):
		spawn("rifle", -0.95, 0.34); spawn("rifle", -0.6, 0.32); spawn("rifle", 1.5, 0.34); spawn("rifle", -0.2, 0.3)
	if _at("t", 2.0):
		spawn("tank", 0.0, 1.0)
		hint.text = "دبابة! اختار RPG وصوّب بين البرج والبدن"
		_select("rpg")
	if _at("h", 9.0) and tank != null and not tank.dead:
		hint.text = "نقطة الضعف: الحلقة بين البرج والبدن (الدايرة)"
	if _at("r", 14.0):
		spawn("runner", -0.25, 0.35); spawn("runner", 0.25, 0.35)
	if st > 6.0 and spawned.has("r") and _alive() == 0:
		msg_l.text = "النقطة اتأمّنت ✔"
		_finish_p3()

func _finish_p3() -> void:
	if go_btn.visible:
		return
	go_btn.text = "النهاية ◀"
	go_btn.visible = true

func _tick_enemies(dt: float, live: bool) -> void:
	var rem: Array = []
	for e in enemies:
		var arr := _frames(e)
		if e.kind == "tank":
			if e.dead:
				e.fade -= dt * 0.8
				if e.fade <= 0.0:
					e.done = true
					rem.append(e)
				_pose(e)
				continue
			e.fi = minf(e.fi + dt * 8.0, float(arr.size() - 1))
			_pose(e)
			if live and e.fi >= 40.0:
				tank_shot -= dt
				if tank_shot <= 0.0:
					tank_shot = 6.5
					_boom(Vector2(W * 0.5, H * 0.62), 1.2)
					_hurt(18.0)
			continue
		if e.dead:
			e.t += dt
			e.fi = minf(e.fi + dt * 12.0, 46.0)
			if e.t > 1.8:
				e.fade -= dt * 1.5
			if e.fade <= 0.0:
				e.done = true
				rem.append(e)
			e.anim = "die"
			_pose(e)
			continue
		e.t += dt
		if not live:
			_pose(e)
			continue
		match e.kind:
			"rifle":
				e.fi = fmod(e.fi + dt * 8.0, 64.0)
				e.next_shot -= dt
				if e.next_shot <= 0.0:
					e.next_shot = randf_range(1.8, 3.2)
					_tracer(e.node.position + Vector2(0, -150.0 * e.s), Vector2(randf_range(80, W - 80), H - 10), Color(1, 0.4, 0.3))
					_hurt(4.0 + 4.0 * e.s)
			"runner":
				e.fi = fmod(e.fi + dt * 8.0, 64.0)
				e.s += e.spd * dt
				if e.s >= 0.95:
					_hurt(14.0)
					e.done = true
					rem.append(e)
			"gren":
				e.fi = minf(e.fi + dt * 8.0, 63.0)
				if e.fi >= 28.0 and not e.thrown:
					e.thrown = true
					var tw := create_tween()
					tw.tween_interval(1.0)
					tw.tween_callback(func():
						if not e.dead and not ending:
							_boom(Vector2(W * 0.5, H * 0.8), 1.0)
							_hurt(16.0))
				if e.fi >= 63.0 and not e.dead:
					e.done = true
					rem.append(e)
		_pose(e)
	for e in rem:
		e.node.queue_free()
		enemies.erase(e)
	_ring_update()

var ring: Line2D
func _ring_update() -> void:
	if ring == null:
		ring = Line2D.new()
		ring.width = 5.0
		ring.default_color = Color(1, 0.9, 0.2, 0.95)
		ring.z_index = 250
		ring.closed = true
		for i in 32:
			ring.add_point(Vector2(cos(TAU * i / 32.0), sin(TAU * i / 32.0)) * 44.0)
		world.add_child(ring)
	var show := tank != null and not tank.dead and tank.fi > 20.0 and hint.text.find("الدايرة") >= 0
	ring.visible = show
	if show:
		var r := _rect(tank)
		ring.position = r.position + Vector2(r.size.x * 0.5, r.size.y * 0.44)
		ring.scale = Vector2.ONE * (1.0 + sin(st * 6.0) * 0.12)
