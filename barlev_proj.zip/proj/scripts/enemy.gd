class_name Enemy
extends StaticBody3D
# One script for every enemy kind: "soldier", "bunker", "tank", "sniper".

var kind := "soldier"
var main: Node
var hp := 2.0
var active := false
var dead := false
var phase := "hidden"
var t := 0.0
var visual: Node3D
var bang: Label3D
var laser: MeshInstance3D
var weak: StaticBody3D
var col: CollisionShape3D
var base_mats: Array = []
var patrol_min := -12.0
var patrol_max := 12.0
var dir := 1.0
var act_range := 38.0

func setup(k: String, m: Node) -> void:
	kind = k
	main = m
	visual = Node3D.new()
	add_child(visual)
	col = CollisionShape3D.new()
	var sh := BoxShape3D.new()
	col.shape = sh
	add_child(col)
	match kind:
		"soldier":
			hp = 2.0
			sh.size = Vector3(0.8, 1.8, 0.6)
			col.position = Vector3(0, 0.9, 0)
			_mesh_box(Vector3(0.7, 1.1, 0.4), Vector3(0, 0.75, 0), Color(0.40, 0.42, 0.25))
			_mesh_sphere(0.23, Vector3(0, 1.5, 0), Color(0.85, 0.65, 0.5))
			_mesh_box(Vector3(0.5, 0.18, 0.5), Vector3(0, 1.68, 0), Color(0.30, 0.32, 0.20))
			_mesh_box(Vector3(0.08, 0.08, 0.7), Vector3(0.25, 1.0, -0.35), Color(0.1, 0.1, 0.1))
			visual.position.y = -2.0
			collision_layer = 0
			act_range = 36.0
		"bunker":
			hp = 10.0
			sh.size = Vector3(8, 3, 5)
			col.position = Vector3(0, 1.5, 0)
			_mesh_box(Vector3(8, 3, 5), Vector3(0, 1.5, 0), Color(0.55, 0.55, 0.52))
			_mesh_box(Vector3(5, 0.6, 0.3), Vector3(0, 2.0, -2.55), Color(0.05, 0.05, 0.05))
			_mesh_box(Vector3(0.12, 0.12, 1.4), Vector3(0, 2.0, -3.0), Color(0.1, 0.1, 0.1))
			act_range = 55.0
			phase = "up"
		"tank":
			hp = 1.0
			sh.size = Vector3(4.2, 2.0, 7)
			col.position = Vector3(0, 1.0, 0)
			_mesh_box(Vector3(3.8, 1.2, 6.4), Vector3(0, 0.7, 0), Color(0.45, 0.4, 0.28))
			_mesh_box(Vector3(2.4, 0.9, 2.8), Vector3(0, 1.55, -0.3), Color(0.5, 0.45, 0.3))
			_mesh_box(Vector3(0.28, 0.28, 4.2), Vector3(0, 1.6, 2.6), Color(0.2, 0.2, 0.2))
			weak = StaticBody3D.new()
			weak.position = Vector3(0, 2.5, -0.2)
			var wc := CollisionShape3D.new()
			var ws := BoxShape3D.new()
			ws.size = Vector3(1.4, 0.8, 1.4)
			wc.shape = ws
			weak.add_child(wc)
			weak.add_to_group("tankweak")
			weak.set_meta("tank", self)
			add_child(weak)
			var wm := MeshInstance3D.new()
			var wbm := BoxMesh.new()
			wbm.size = Vector3(1.0, 0.2, 1.0)
			var wmat := StandardMaterial3D.new()
			wmat.albedo_color = Color(0.9, 0.15, 0.1)
			wmat.emission_enabled = true
			wmat.emission = Color(0.8, 0.1, 0.05)
			wbm.material = wmat
			wm.mesh = wbm
			wm.position = Vector3(0, -0.3, 0)
			weak.add_child(wm)
			act_range = 70.0
			phase = "idle"
		"sniper":
			hp = 1.0
			sh.size = Vector3(0.7, 1.4, 0.6)
			col.position = Vector3(0, 0.7, 0)
			_mesh_box(Vector3(0.6, 0.8, 0.4), Vector3(0, 0.5, 0), Color(0.3, 0.3, 0.2))
			_mesh_sphere(0.2, Vector3(0, 1.1, 0), Color(0.8, 0.6, 0.5))
			_mesh_box(Vector3(0.07, 0.07, 1.0), Vector3(0.2, 0.7, -0.5), Color(0.1, 0.1, 0.1))
			act_range = 90.0
			phase = "idle"
	bang = Label3D.new()
	bang.text = "!"
	bang.font_size = 160
	bang.modulate = Color(1, 0.1, 0.1)
	bang.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	bang.no_depth_test = true
	bang.visible = false
	bang.position = Vector3(0, 2.6 if kind != "tank" else 4.2, 0)
	add_child(bang)
	add_to_group("enemy")
	if kind == "bunker" or kind == "tank":
		add_to_group("must")

func _mesh_box(size: Vector3, pos: Vector3, c: Color) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	var mat := StandardMaterial3D.new()
	mat.albedo_color = c
	mat.roughness = 1.0
	bm.material = mat
	mi.mesh = bm
	mi.position = pos
	visual.add_child(mi)

func _mesh_sphere(r: float, pos: Vector3, c: Color) -> void:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = r
	sm.height = r * 2.0
	var mat := StandardMaterial3D.new()
	mat.albedo_color = c
	sm.material = mat
	mi.mesh = sm
	mi.position = pos
	visual.add_child(mi)

func take_damage(amount: float, _src: String = "") -> void:
	if dead:
		return
	if kind == "tank":
		return # only the weak spot hit by an RPG destroys a tank
	if kind == "soldier" and phase != "up" and phase != "aim" and phase != "fire":
		return
	hp -= amount
	if hp <= 0.0:
		die()

func destroy_tank() -> void:
	if kind == "tank" and not dead:
		die()

func die() -> void:
	dead = true
	collision_layer = 0
	bang.visible = false
	if laser:
		laser.visible = false
	main.enemy_died(self)
	var tw := create_tween()
	if kind == "soldier" or kind == "sniper":
		tw.tween_property(visual, "rotation_degrees:x", -85.0, 0.3)
		tw.tween_interval(0.8)
		tw.tween_property(visual, "position:y", -2.0, 0.4)
	else:
		tw.tween_property(visual, "scale", Vector3(1, 0.4, 1), 0.5)
		tw.tween_interval(2.0)
	tw.tween_callback(queue_free)

func _player_pos() -> Vector3:
	return main.player.global_position + Vector3(0, 0.9, 0)

func _blocked() -> bool:
	return main.line_blocked(global_position + Vector3(0, 1.6 if kind != "tank" else 2.4, 0), _player_pos(), self)

func _physics_process(delta: float) -> void:
	if dead or main.state != "play":
		return
	var dist := global_position.distance_to(main.player.global_position)
	if not active:
		if dist < act_range:
			active = true
			t = randf_range(0.2, 1.8)
		else:
			return
	t -= delta
	match kind:
		"soldier":
			_soldier()
		"bunker":
			_bunker()
		"tank":
			_tank(delta)
		"sniper":
			_sniper(delta)

func _face_player() -> void:
	var p: Vector3 = main.player.global_position
	look_at(Vector3(p.x, global_position.y, p.z), Vector3.UP)
	if kind == "soldier" or kind == "sniper":
		rotate_y(PI)

func _soldier() -> void:
	match phase:
		"hidden":
			if t <= 0.0:
				phase = "rising"
				t = 0.35
				collision_layer = 1
		"rising":
			visual.position.y = lerp(-2.0, 0.0, 1.0 - clamp(t / 0.35, 0.0, 1.0))
			if t <= 0.0:
				visual.position.y = 0.0
				phase = "aim"
				t = randf_range(0.8, 1.2)
				bang.visible = true
				_face_player()
		"aim":
			if t <= 0.0:
				phase = "fire"
				t = 0.2
		"fire":
			bang.visible = false
			if t <= 0.0:
				var dist := global_position.distance_to(main.player.global_position)
				if not _blocked():
					var p: float = clamp(0.85 - dist / 70.0, 0.2, 0.7)
					if randf() < p:
						main.hurt(9.0)
				phase = "up"
				t = randf_range(1.0, 1.8)
		"up":
			if t <= 0.0:
				phase = "aim"
				t = randf_range(0.7, 1.0)
				bang.visible = true
				if randf() < 0.45:
					phase = "ducking"
					t = 0.3
					bang.visible = false
		"ducking":
			visual.position.y = lerp(0.0, -2.0, 1.0 - clamp(t / 0.3, 0.0, 1.0))
			if t <= 0.0:
				collision_layer = 0
				phase = "hidden"
				t = randf_range(1.2, 2.6)

func _bunker() -> void:
	if phase == "up":
		if t <= 0.0:
			phase = "aim"
			t = 1.0
			bang.visible = true
			_face_player()
	elif phase == "aim":
		if t <= 0.0:
			bang.visible = false
			if not _blocked():
				if randf() < 0.6:
					main.hurt(12.0)
			phase = "up"
			t = 1.4

func _tank(delta: float) -> void:
	if phase == "idle" or phase == "move":
		position.x += dir * 1.6 * delta
		if position.x > patrol_max:
			dir = -1.0
		elif position.x < patrol_min:
			dir = 1.0
		if t <= 0.0:
			phase = "aim"
			t = 1.5
			bang.visible = true
	elif phase == "aim":
		if t <= 0.0:
			bang.visible = false
			if not _blocked():
				main.hurt(35.0)
			main.flash_msg("TANK FIRED!")
			phase = "idle"
			t = 4.0

func _sniper(_delta: float) -> void:
	if phase == "idle":
		if t <= 0.0:
			phase = "aim"
			t = 1.6
			bang.visible = true
			_face_player()
	elif phase == "aim":
		if t <= 0.0:
			bang.visible = false
			if not _blocked():
				main.hurt(35.0)
			phase = "idle"
			t = 3.5
