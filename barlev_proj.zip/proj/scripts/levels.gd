class_name Levels
extends RefCounted
# Builds the 5 levels in code. z goes negative as the player advances.

const SAND := Color(0.72, 0.58, 0.38)
const CONCRETE := Color(0.55, 0.55, 0.52)

static func names() -> Array:
	return ["East Bank - Training Under Fire", "The Sand Rampart", "Trenches and the First Tank",
		"Bunkers Complex", "Snipers and Armor"]

static func box(root: Node3D, pos: Vector3, size: Vector3, c: Color, rot_x := 0.0, cover := false) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	body.rotation_degrees.x = rot_x
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	var mat := StandardMaterial3D.new()
	mat.albedo_color = c
	mat.roughness = 1.0
	bm.material = mat
	mi.mesh = bm
	body.add_child(mi)
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	cs.shape = sh
	body.add_child(cs)
	if cover:
		body.add_to_group("cover")
	root.add_child(body)
	return body

# Sand rampart: slope up, plateau, slope down. z0 is where the slope starts.
static func berm(root: Node3D, z0: float, width := 80.0) -> void:
	var ang := 25.0
	var h := 4.0
	var run := h / tan(deg_to_rad(ang))
	var slope_len := sqrt(run * run + h * h)
	var a := deg_to_rad(ang)
	var n_up := Vector3(0, cos(a), sin(a))
	var mid_up := Vector3(0, h / 2.0, z0 - run / 2.0)
	box(root, mid_up - n_up * 1.0, Vector3(width, 2.0, slope_len), SAND, ang)
	box(root, Vector3(0, h - 1.0, z0 - run - 2.0), Vector3(width, 2.0, 4.0), SAND)
	var n_dn := Vector3(0, cos(a), -sin(a))
	var mid_dn := Vector3(0, h / 2.0, z0 - run - 4.0 - run / 2.0)
	box(root, mid_dn - n_dn * 1.0, Vector3(width, 2.0, slope_len), SAND, -ang)

static func wall(root: Node3D, x: float, z: float, w := 4.0) -> void:
	box(root, Vector3(x, 1.0, z), Vector3(w, 2.0, 0.7), Color(0.62, 0.52, 0.36), 0.0, true)

static func enemy(root: Node3D, main: Node, kind: String, pos: Vector3) -> Enemy:
	var e := Enemy.new()
	e.position = pos
	root.add_child(e)
	e.setup(kind, main)
	return e

static func soldiers(root: Node3D, main: Node, z: float, xs: Array) -> void:
	for x in xs:
		enemy(root, main, "soldier", Vector3(x, 0, z))
		box(root, Vector3(x, 0.35, z + 1.2), Vector3(1.6, 0.7, 0.5), Color(0.6, 0.5, 0.33))

static func tank(root: Node3D, main: Node, z: float, x_min: float, x_max: float) -> void:
	var e := enemy(root, main, "tank", Vector3(randf_range(x_min, x_max), 0, z))
	e.patrol_min = x_min
	e.patrol_max = x_max

static func flag(root: Node3D, z: float) -> void:
	box(root, Vector3(0, 4, z), Vector3(0.3, 8, 0.3), Color(0.2, 0.7, 0.2))
	box(root, Vector3(1.0, 7, z), Vector3(2.0, 1.2, 0.1), Color(0.8, 0.1, 0.1))

static func mg_mount(root: Node3D, pos: Vector3) -> Node3D:
	var m := Node3D.new()
	m.position = pos
	m.add_to_group("mg_mount")
	root.add_child(m)
	box(root, pos + Vector3(0, 0.5, 0.9), Vector3(3.0, 1.0, 0.6), Color(0.6, 0.5, 0.33), 0.0, true)
	box(root, pos + Vector3(0, 0.9, 0), Vector3(0.15, 0.15, 1.2), Color(0.1, 0.1, 0.1))
	box(root, pos + Vector3(0, 0.45, 0), Vector3(0.2, 0.9, 0.2), Color(0.15, 0.15, 0.15))
	return m

static func build(root: Node3D, idx: int, main: Node) -> Dictionary:
	var info := {"start": Vector3(0, 1.0, 8), "end_z": -80.0, "checkpoints": [],
		"weapons": ["ak", "gren"], "gren": 4, "rpg": 0, "sniper": 0, "intro": ""}
	# Wide ground and far wall so the player cannot wander off
	box(root, Vector3(0, -0.5, -60), Vector3(120, 1, 260), Color(0.80, 0.65, 0.42))
	box(root, Vector3(-60, 3, -60), Vector3(1, 6, 260), Color(0.6, 0.5, 0.35))
	box(root, Vector3(60, 3, -60), Vector3(1, 6, 260), Color(0.6, 0.5, 0.35))
	box(root, Vector3(0, 3, 12), Vector3(120, 6, 1), Color(0.6, 0.5, 0.35))
	match idx:
		0:
			info["intro"] = "Level 1: move with the left stick, aim with the right side, shoot. Throw grenades at trenches."
			berm(root, -30.0)
			wall(root, -6, -8)
			wall(root, 5, -16)
			wall(root, -4, -23)
			soldiers(root, main, -14.0, [-7.0, 6.0])
			soldiers(root, main, -22.0, [-12.0, 0.0, 10.0])
			soldiers(root, main, -58.0, [-9.0, 9.0, 0.0])
			wall(root, -4, -52)
			wall(root, 6, -56)
			info["end_z"] = -78.0
			info["checkpoints"] = [-27.0, -56.0]
			flag(root, -80.0)
		1:
			info["weapons"] = ["ak", "gren", "rpg"]
			info["rpg"] = 5
			info["intro"] = "Level 2: RPG-7 acquired. Destroy the concrete bunkers with rockets, then reach the flag."
			berm(root, -26.0)
			wall(root, -5, -8)
			wall(root, -1, -12)
			soldiers(root, main, -16.0, [-8.0, 8.0])
			soldiers(root, main, -22.0, [0.0])
			wall(root, 0, -54)
			wall(root, -12, -58)
			wall(root, 12, -58)
			soldiers(root, main, -60.0, [-6.0, 6.0])
			enemy(root, main, "bunker", Vector3(0, 0, -75))
			enemy(root, main, "bunker", Vector3(-16, 0, -80))
			soldiers(root, main, -70.0, [-10.0, 10.0])
			info["end_z"] = -98.0
			info["checkpoints"] = [-23.0, -56.0]
			flag(root, -100.0)
		2:
			info["weapons"] = ["ak", "gren", "rpg"]
			info["rpg"] = 6
			info["intro"] = "Level 3: use the fixed machine gun (USE button), then hit the tank's red weak spot with the RPG. Hide behind walls from tank fire."
			berm(root, -22.0)
			wall(root, 6, -10)
			wall(root, -6, -16)
			soldiers(root, main, -18.0, [-10.0, 4.0, 12.0])
			mg_mount(root, Vector3(0, 0, -46.0))
			wall(root, -8, -50)
			wall(root, 8, -50)
			soldiers(root, main, -60.0, [-14.0, -8.0, -2.0, 4.0, 10.0, 15.0])
			wall(root, -8, -72)
			wall(root, 0, -72, 6.0)
			wall(root, 8, -72)
			tank(root, main, -92.0, -14.0, 14.0)
			soldiers(root, main, -84.0, [-12.0, 12.0])
			info["end_z"] = -112.0
			info["checkpoints"] = [-19.0, -48.0, -74.0]
			flag(root, -114.0)
		3:
			info["weapons"] = ["ak", "gren", "rpg"]
			info["gren"] = 6
			info["rpg"] = 7
			info["intro"] = "Level 4: a chain of bunkers. Close combat, many grenades. Clear every bunker and the tank."
			berm(root, -20.0)
			wall(root, -5, -8)
			wall(root, 5, -13)
			soldiers(root, main, -16.0, [-8.0, 8.0, 0.0])
			wall(root, -10, -48)
			wall(root, 10, -48)
			soldiers(root, main, -52.0, [-12.0, -4.0, 6.0, 14.0])
			enemy(root, main, "bunker", Vector3(-10, 0, -66))
			wall(root, 6, -62)
			soldiers(root, main, -72.0, [4.0, 12.0])
			enemy(root, main, "bunker", Vector3(10, 0, -84))
			wall(root, -6, -78)
			soldiers(root, main, -88.0, [-12.0, 0.0])
			enemy(root, main, "bunker", Vector3(-6, 0, -104))
			wall(root, 2, -98, 6.0)
			wall(root, -14, -98)
			tank(root, main, -120.0, -16.0, 16.0)
			wall(root, -8, -112)
			wall(root, 8, -112)
			info["end_z"] = -138.0
			info["checkpoints"] = [-18.0, -50.0, -76.0, -100.0]
			flag(root, -140.0)
		4:
			info["weapons"] = ["ak", "gren", "rpg", "sniper"]
			info["gren"] = 6
			info["rpg"] = 8
			info["sniper"] = 8
			info["intro"] = "Level 5: snipers on the rampart and armor ahead. Use the sniper rifle against snipers, RPG on tank weak spots."
			berm(root, -20.0)
			wall(root, -6, -8)
			wall(root, 6, -14)
			enemy(root, main, "sniper", Vector3(-20, 4, -30.6))
			enemy(root, main, "sniper", Vector3(22, 4, -30.6))
			soldiers(root, main, -16.0, [-9.0, 9.0])
			wall(root, -10, -46)
			wall(root, 10, -46)
			wall(root, 0, -50, 6.0)
			soldiers(root, main, -54.0, [-14.0, -6.0, 6.0, 14.0])
			enemy(root, main, "bunker", Vector3(0, 0, -70))
			tank(root, main, -88.0, -15.0, -2.0)
			tank(root, main, -88.0, 2.0, 15.0)
			wall(root, -8, -78)
			wall(root, 8, -78)
			wall(root, 0, -78, 6.0)
			soldiers(root, main, -96.0, [-16.0, -8.0, 0.0, 8.0, 16.0])
			enemy(root, main, "sniper", Vector3(-24, 0, -108))
			enemy(root, main, "sniper", Vector3(24, 0, -108))
			enemy(root, main, "bunker", Vector3(-12, 0, -116))
			enemy(root, main, "bunker", Vector3(12, 0, -116))
			wall(root, -6, -106)
			wall(root, 6, -106)
			info["end_z"] = -132.0
			info["checkpoints"] = [-18.0, -48.0, -80.0, -104.0]
			flag(root, -134.0)
	return info
