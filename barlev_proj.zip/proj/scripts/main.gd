extends Node3D
# Bar Lev v0.1 - five playable levels with placeholder graphics.

const MOVE_SPEED := 5.5
const LOOK_SENS := 0.0035
const HP_MAX := 100.0
const PLAY_URL := "https://play.google.com/store/apps/details?id=com.khaled.barlev"

var player: CharacterBody3D
var cam: Camera3D
var ray: RayCast3D
var flash: OmniLight3D
var gun_mesh: MeshInstance3D
var level_root: Node3D
var level_idx := 0
var info := {}
var state := "play" # play, dead, done, win
var hp := HP_MAX
var regen_wait := 0.0
var yaw := 0.0
var pitch := 0.0
var move_vec := Vector2.ZERO
var move_touch := -1
var look_touch := -1
var fire_touch := -1
var joy_origin := Vector2.ZERO
var weapons: Array = []
var cur := 0
var stock := {"gren": 0, "rpg": 0, "sniper": 0}
var mag := 30
var reload_t := 0.0
var fire_cd := 0.0
var mounted := false
var near_mg: Node3D = null
var checkpoint := Vector3.ZERO
var cp_list: Array = []
var must_left := 0
var kills := 0
var level_time := 0.0
var msg_t := 0.0
var warned_end := false
# HUD
var layer: CanvasLayer
var hp_bar: ColorRect
var hp_back: ColorRect
var lbl_ammo: Label
var lbl_obj: Label
var lbl_msg: Label
var lbl_title: Label
var damage_flash: ColorRect
var joy_base: ColorRect
var joy_knob: ColorRect
var btn_fire: Control
var btn_use: Control
var btn_weapons: Array = []
var big_panel: ColorRect
var big_label: Label
var btn_rate: Control

func _ready() -> void:
	randomize()
	_build_env()
	_build_player()
	_build_hud()
	get_viewport().size_changed.connect(_layout_hud)
	load_level(0)

func _build_env() -> void:
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.62, 0.78, 0.93)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(1.0, 0.9, 0.75)
	e.ambient_light_energy = 0.6
	e.fog_enabled = true
	e.fog_light_color = Color(0.86, 0.80, 0.68)
	e.fog_density = 0.004
	env.environment = e
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-45, -30, 0)
	sun.light_energy = 1.2
	add_child(sun)

func _build_player() -> void:
	player = CharacterBody3D.new()
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	player.add_child(cs)
	player.floor_max_angle = deg_to_rad(50.0)
	cam = Camera3D.new()
	cam.position = Vector3(0, 0.7, 0)
	cam.fov = 75
	player.add_child(cam)
	ray = RayCast3D.new()
	ray.target_position = Vector3(0, 0, -200)
	ray.enabled = true
	cam.add_child(ray)
	flash = OmniLight3D.new()
	flash.position = Vector3(0.2, -0.1, -0.8)
	flash.light_energy = 0.0
	flash.omni_range = 6.0
	cam.add_child(flash)
	gun_mesh = MeshInstance3D.new()
	var gm := BoxMesh.new()
	gm.size = Vector3(0.06, 0.08, 0.6)
	var gmat := StandardMaterial3D.new()
	gmat.albedo_color = Color(0.15, 0.12, 0.1)
	gm.material = gmat
	gun_mesh.mesh = gm
	gun_mesh.position = Vector3(0.22, -0.24, -0.75)
	cam.add_child(gun_mesh)
	add_child(player)

# ---------- HUD ----------
func _mk_label(size: int, col := Color.WHITE) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	layer.add_child(l)
	return l

func _mk_button(text: String, size: Vector2) -> Control:
	var r := ColorRect.new()
	r.color = Color(0, 0, 0, 0.45)
	r.size = size
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 26)
	l.size = size
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	r.add_child(l)
	layer.add_child(r)
	return r

func _build_hud() -> void:
	layer = CanvasLayer.new()
	add_child(layer)
	damage_flash = ColorRect.new()
	damage_flash.color = Color(1, 0, 0, 0)
	damage_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(damage_flash)
	var cross := _mk_label(40)
	cross.name = "cross"
	cross.text = "+"
	hp_back = ColorRect.new()
	hp_back.color = Color(0, 0, 0, 0.5)
	layer.add_child(hp_back)
	hp_bar = ColorRect.new()
	hp_bar.color = Color(0.2, 0.8, 0.25)
	layer.add_child(hp_bar)
	lbl_ammo = _mk_label(30)
	lbl_obj = _mk_label(26)
	lbl_msg = _mk_label(30, Color(1, 0.9, 0.4))
	lbl_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lbl_title = _mk_label(24, Color(1, 1, 1, 0.8))
	joy_base = ColorRect.new()
	joy_base.color = Color(1, 1, 1, 0.15)
	joy_base.size = Vector2(160, 160)
	joy_base.visible = false
	layer.add_child(joy_base)
	joy_knob = ColorRect.new()
	joy_knob.color = Color(1, 1, 1, 0.45)
	joy_knob.size = Vector2(70, 70)
	joy_knob.visible = false
	layer.add_child(joy_knob)
	btn_fire = _mk_button("FIRE", Vector2(190, 190))
	btn_use = _mk_button("USE", Vector2(150, 90))
	big_panel = ColorRect.new()
	big_panel.color = Color(0, 0, 0, 0.7)
	big_panel.visible = false
	layer.add_child(big_panel)
	big_label = _mk_label(40)
	big_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	big_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	big_label.visible = false
	btn_rate = _mk_button("RATE US ON GOOGLE PLAY", Vector2(420, 80))
	btn_rate.visible = false
	_layout_hud()

func _layout_hud() -> void:
	var vs := get_viewport().get_visible_rect().size
	damage_flash.size = vs
	var cross := layer.get_node("cross") as Label
	cross.position = vs / 2.0 - Vector2(12, 28)
	hp_back.position = Vector2(20, 16)
	hp_back.size = Vector2(300, 22)
	hp_bar.position = Vector2(22, 18)
	lbl_ammo.position = Vector2(20, 46)
	lbl_obj.position = Vector2(20, 90)
	lbl_title.position = Vector2(vs.x - 520, 12)
	lbl_msg.position = Vector2(vs.x / 2.0 - 450, vs.y * 0.18)
	lbl_msg.size = Vector2(900, 120)
	btn_fire.position = Vector2(vs.x - 220, vs.y - 230)
	btn_use.position = Vector2(vs.x - 400, vs.y - 120)
	for i in btn_weapons.size():
		btn_weapons[i].position = Vector2(vs.x - 150, 70 + i * 74)
	big_panel.position = Vector2.ZERO
	big_panel.size = vs
	big_label.position = Vector2(0, 0)
	big_label.size = vs
	btn_rate.position = Vector2(vs.x / 2.0 - 210, vs.y * 0.74)

func _rebuild_weapon_buttons() -> void:
	for b in btn_weapons:
		b.queue_free()
	btn_weapons.clear()
	var names := {"ak": "AK-47", "gren": "GRENADE", "rpg": "RPG-7", "sniper": "SNIPER"}
	for w in weapons:
		var b := _mk_button(names[w], Vector2(130, 64))
		btn_weapons.append(b)
	_layout_hud()

func flash_msg(text: String, secs := 2.5) -> void:
	lbl_msg.text = text
	msg_t = secs

func _update_hud() -> void:
	hp_bar.size = Vector2(296.0 * clamp(hp / HP_MAX, 0.0, 1.0), 18)
	var w: String = weapons[cur]
	var txt := ""
	if mounted:
		txt = "FIXED MG  (USE to leave)"
	elif reload_t > 0.0:
		txt = "RELOADING..."
	elif w == "ak":
		txt = "AK-47   %d/30" % mag
	elif w == "gren":
		txt = "GRENADES  x%d" % stock["gren"]
	elif w == "rpg":
		txt = "RPG-7  x%d" % stock["rpg"]
	else:
		txt = "SNIPER  x%d" % stock["sniper"]
	lbl_ammo.text = txt
	lbl_obj.text = ("Destroy fortified targets: %d" % must_left) if must_left > 0 else "Reach the flag!"
	lbl_title.text = "L%d  %s" % [level_idx + 1, Levels.names()[level_idx]]
	for i in btn_weapons.size():
		btn_weapons[i].color = Color(0.9, 0.7, 0.1, 0.6) if i == cur else Color(0, 0, 0, 0.45)
	btn_use.visible = near_mg != null or mounted

# ---------- levels ----------
func load_level(idx: int) -> void:
	level_idx = idx
	if level_root:
		level_root.queue_free()
		await get_tree().process_frame
	level_root = Node3D.new()
	add_child(level_root)
	info = Levels.build(level_root, idx, self)
	weapons = info["weapons"].duplicate()
	stock["gren"] = info["gren"]
	stock["rpg"] = info["rpg"]
	stock["sniper"] = info["sniper"]
	cur = 0
	mag = 30
	reload_t = 0.0
	mounted = false
	near_mg = null
	hp = HP_MAX
	kills = 0
	level_time = 0.0
	warned_end = false
	cp_list = info["checkpoints"].duplicate()
	checkpoint = info["start"]
	_respawn_player()
	state = "play"
	big_panel.visible = false
	big_label.visible = false
	await get_tree().process_frame
	must_left = get_tree().get_nodes_in_group("must").size()
	_rebuild_weapon_buttons()
	flash_msg(info["intro"], 6.0)
	_apply_weapon_look()
	_update_hud()

func _respawn_player() -> void:
	player.global_position = checkpoint
	player.velocity = Vector3.ZERO
	yaw = 0.0
	pitch = 0.0

func enemy_died(e: Enemy) -> void:
	kills += 1
	if e.is_in_group("must"):
		must_left = max(0, must_left - 1)
		if must_left == 0:
			flash_msg("All fortified targets destroyed! Reach the flag.", 3.5)
	_update_hud()

func line_blocked(from: Vector3, to: Vector3, who: Node) -> bool:
	var q := PhysicsRayQueryParameters3D.create(from, to)
	q.exclude = [player.get_rid(), who.get_rid()]
	if who is Enemy and (who as Enemy).weak != null:
		q.exclude.append((who as Enemy).weak.get_rid())
	q.collision_mask = 1
	var r := get_world_3d().direct_space_state.intersect_ray(q)
	if r.is_empty():
		return false
	var c: Object = r["collider"]
	return not (c is Enemy)

func hurt(amount: float) -> void:
	if state != "play":
		return
	hp -= amount
	regen_wait = 4.0
	damage_flash.color.a = 0.45
	if hp <= 0.0:
		hp = 0.0
		state = "dead"
		mounted = false
		_show_big("YOU DIED\n\nTap to continue from the last checkpoint")
	_update_hud()

func _show_big(text: String) -> void:
	big_label.text = text
	big_panel.visible = true
	big_label.visible = true

# ---------- weapons ----------
func _apply_weapon_look() -> void:
	var w: String = weapons[cur]
	cam.fov = 22.0 if (w == "sniper" and not mounted) else 75.0
	gun_mesh.visible = not mounted

func select_weapon(i: int) -> void:
	if i >= weapons.size() or mounted:
		return
	cur = i
	reload_t = 0.0
	_apply_weapon_look()
	_update_hud()

func _try_fire() -> void:
	if fire_cd > 0.0 or reload_t > 0.0 or state != "play":
		return
	if mounted:
		fire_cd = 0.07
		_hitscan(0.6, "mg")
		return
	var w: String = weapons[cur]
	match w:
		"ak":
			fire_cd = 0.11
			mag -= 1
			_hitscan(1.0, "ak")
			if mag <= 0:
				reload_t = 1.6
		"gren":
			if stock["gren"] <= 0:
				flash_msg("No grenades")
				return
			stock["gren"] -= 1
			fire_cd = 0.9
			_throw_grenade()
		"rpg":
			if stock["rpg"] <= 0:
				flash_msg("No rockets")
				return
			stock["rpg"] -= 1
			fire_cd = 2.2
			_fire_rpg()
		"sniper":
			if stock["sniper"] <= 0:
				flash_msg("No sniper ammo")
				return
			stock["sniper"] -= 1
			fire_cd = 1.2
			_hitscan(5.0, "sniper")
	_update_hud()

func _hitscan(dmg: float, src: String) -> void:
	flash.light_energy = 6.0
	ray.force_raycast_update()
	if not ray.is_colliding():
		return
	var c := ray.get_collider()
	if c is Enemy:
		(c as Enemy).take_damage(dmg * (0.4 if (c as Enemy).kind == "bunker" else 1.0), src)

func _throw_grenade() -> void:
	var g := RigidBody3D.new()
	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 0.15
	cs.shape = sh
	g.add_child(cs)
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.15
	sm.height = 0.3
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.2, 0.3, 0.15)
	sm.material = mat
	mi.mesh = sm
	g.add_child(mi)
	level_root.add_child(g)
	g.global_position = cam.global_position + (-cam.global_transform.basis.z) * 0.8
	g.linear_velocity = (-cam.global_transform.basis.z) * 15.0 + Vector3.UP * 5.0
	var tm := get_tree().create_timer(1.8)
	tm.timeout.connect(func():
		if is_instance_valid(g):
			explosion(g.global_position, 4.5, 3.0, 3.0)
			g.queue_free())

func _fire_rpg() -> void:
	flash.light_energy = 10.0
	ray.force_raycast_update()
	var hit_pos := cam.global_position + (-cam.global_transform.basis.z) * 60.0
	if ray.is_colliding():
		hit_pos = ray.get_collision_point()
		var c := ray.get_collider()
		if c is Node and (c as Node).is_in_group("tankweak"):
			var tk: Enemy = (c as Node).get_meta("tank")
			tk.destroy_tank()
			flash_msg("DIRECT HIT ON THE WEAK SPOT!", 2.0)
		elif c is Enemy and (c as Enemy).kind == "bunker":
			(c as Enemy).take_damage(10.0, "rpg")
		elif c is Enemy and (c as Enemy).kind == "tank":
			flash_msg("The rocket bounced off the armor - aim at the red spot!", 2.5)
	explosion(hit_pos, 3.5, 3.0, 0.0)

func explosion(pos: Vector3, radius: float, soldier_dmg: float, bunker_dmg: float) -> void:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 1.0
	sm.height = 2.0
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.5, 0.1)
	mat.emission_enabled = true
	mat.emission = Color(1.0, 0.4, 0.05)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm.material = mat
	mi.mesh = sm
	level_root.add_child(mi)
	mi.global_position = pos
	mi.scale = Vector3.ONE * 0.3
	var tw := create_tween()
	tw.tween_property(mi, "scale", Vector3.ONE * radius * 0.6, 0.25)
	tw.tween_callback(mi.queue_free)
	for n in get_tree().get_nodes_in_group("enemy"):
		var e := n as Enemy
		if e == null or e.dead:
			continue
		if e.global_position.distance_to(pos) <= radius:
			if e.kind == "soldier" or e.kind == "sniper":
				e.take_damage(soldier_dmg, "blast")
			elif e.kind == "bunker" and bunker_dmg > 0.0:
				e.take_damage(bunker_dmg, "blast")
	if player.global_position.distance_to(pos) < 3.0:
		hurt(20.0)

# ---------- input ----------
func _hit(btn: Control, p: Vector2) -> bool:
	return btn.visible and btn.get_global_rect().has_point(p)

func _press(p: Vector2, idx: int) -> void:
	var vs := get_viewport().get_visible_rect().size
	if state == "dead":
		_continue_after_death()
		return
	if state == "done":
		return
	if state == "win":
		if _hit(btn_rate, p):
			OS.shell_open(PLAY_URL)
		else:
			btn_rate.visible = false
			load_level(0)
		return
	if _hit(btn_fire, p):
		fire_touch = idx
		return
	if _hit(btn_use, p):
		_toggle_mg()
		return
	for i in btn_weapons.size():
		if _hit(btn_weapons[i], p):
			select_weapon(i)
			return
	if p.x < vs.x * 0.4 and move_touch == -1:
		move_touch = idx
		joy_origin = p
		joy_base.position = p - joy_base.size / 2
		joy_knob.position = p - joy_knob.size / 2
		joy_base.visible = true
		joy_knob.visible = true
	elif p.x >= vs.x * 0.4 and look_touch == -1:
		look_touch = idx

func _release(idx: int) -> void:
	if idx == fire_touch:
		fire_touch = -1
	if idx == move_touch:
		move_touch = -1
		move_vec = Vector2.ZERO
		joy_base.visible = false
		joy_knob.visible = false
	if idx == look_touch:
		look_touch = -1

func _input(ev: InputEvent) -> void:
	if ev is InputEventScreenTouch:
		var st := ev as InputEventScreenTouch
		if st.pressed:
			_press(st.position, st.index)
		else:
			_release(st.index)
	elif ev is InputEventScreenDrag:
		var sd := ev as InputEventScreenDrag
		if sd.index == move_touch:
			var d := (sd.position - joy_origin).limit_length(70.0)
			move_vec = d / 70.0
			joy_knob.position = joy_origin + d - joy_knob.size / 2
		elif sd.index == look_touch:
			var k := LOOK_SENS * (0.35 if (weapons[cur] == "sniper" and not mounted) else 1.0)
			yaw -= sd.relative.x * k
			pitch = clamp(pitch - sd.relative.y * k, -1.3, 1.3)
	elif ev is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		yaw -= ev.relative.x * LOOK_SENS
		pitch = clamp(pitch - ev.relative.y * LOOK_SENS, -1.3, 1.3)
	elif ev is InputEventKey and ev.pressed and not ev.echo:
		if ev.keycode >= KEY_1 and ev.keycode <= KEY_4:
			select_weapon(ev.keycode - KEY_1)
		elif ev.keycode == KEY_E:
			_toggle_mg()
		elif state == "dead":
			_continue_after_death()

func _toggle_mg() -> void:
	if mounted:
		mounted = false
		_apply_weapon_look()
	elif near_mg:
		mounted = true
		player.global_position = near_mg.global_position + Vector3(0, 0.9, 1.0)
		yaw = 0.0
		pitch = 0.0
		_apply_weapon_look()
		flash_msg("Fixed machine gun: hold FIRE", 2.0)
	_update_hud()

func _continue_after_death() -> void:
	state = "play"
	hp = HP_MAX
	mag = 30
	reload_t = 0.0
	stock["gren"] = max(stock["gren"], 2)
	stock["rpg"] = max(stock["rpg"], 2) if info["rpg"] > 0 else 0
	stock["sniper"] = max(stock["sniper"], 2) if info["sniper"] > 0 else 0
	big_panel.visible = false
	big_label.visible = false
	_respawn_player()
	_update_hud()

# ---------- loop ----------
func _physics_process(delta: float) -> void:
	if state != "play":
		damage_flash.color.a = max(0.0, damage_flash.color.a - delta)
		return
	level_time += delta
	var kb := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	var mv := move_vec if move_vec != Vector2.ZERO else kb
	if mounted:
		mv = Vector2.ZERO
	player.rotation.y = yaw
	cam.rotation.x = pitch
	var d := (player.transform.basis * Vector3(mv.x, 0, mv.y)).normalized() * mv.length()
	player.velocity.x = d.x * MOVE_SPEED
	player.velocity.z = d.z * MOVE_SPEED
	if player.is_on_floor():
		player.velocity.y = -2.0
	else:
		player.velocity.y -= 22.0 * delta
	player.move_and_slide()
	fire_cd = max(0.0, fire_cd - delta)
	flash.light_energy = max(0.0, flash.light_energy - delta * 40.0)
	damage_flash.color.a = max(0.0, damage_flash.color.a - delta)
	if msg_t > 0.0:
		msg_t -= delta
		if msg_t <= 0.0:
			lbl_msg.text = ""
	if reload_t > 0.0:
		reload_t -= delta
		if reload_t <= 0.0:
			mag = 30
			_update_hud()
	regen_wait = max(0.0, regen_wait - delta)
	if regen_wait == 0.0 and hp < HP_MAX:
		hp = min(HP_MAX, hp + 12.0 * delta)
		hp_bar.size = Vector2(296.0 * hp / HP_MAX, 18)
	if fire_touch != -1 or Input.is_key_pressed(KEY_SPACE):
		_try_fire()
	# checkpoints and nearby fixed MG
	while cp_list.size() > 0 and player.global_position.z < cp_list[0]:
		checkpoint = Vector3(player.global_position.x, 1.0, cp_list[0])
		cp_list.pop_front()
		if info["gren"] > 0:
			stock["gren"] += 1
		if info["rpg"] > 0:
			stock["rpg"] += 1
		if info["sniper"] > 0:
			stock["sniper"] += 2
		flash_msg("Checkpoint saved (+ammo)", 1.8)
		_update_hud()
	var prev := near_mg
	near_mg = null
	for m in get_tree().get_nodes_in_group("mg_mount"):
		if (m as Node3D).global_position.distance_to(player.global_position) < 3.2:
			near_mg = m
	if prev != near_mg:
		_update_hud()
	if player.global_position.y < -5.0:
		_respawn_player()
	# level end
	if player.global_position.z < info["end_z"]:
		if must_left == 0:
			_level_done()
		elif not warned_end:
			warned_end = true
			flash_msg("Destroy all fortified targets first!", 2.5)
	elif player.global_position.z > info["end_z"] + 6.0:
		warned_end = false

func _level_done() -> void:
	if level_idx >= 4:
		state = "win"
		btn_rate.visible = true
		_show_big("YOU WON!\n\nKills: %d   Time: %d s\nEnd of version 0.1\n\nTap to play again" % [kills, int(level_time)])
	else:
		state = "done"
		_show_big("LEVEL %d COMPLETE\n\nKills: %d   Time: %d s" % [level_idx + 1, kills, int(level_time)])
		await get_tree().create_timer(2.5).timeout
		load_level(level_idx + 1)
