# Storm the Bar Lev Line - v0.1 (5 levels, placeholder graphics)

Controls (touch): left side = move stick, right side = look/aim, FIRE button, weapon buttons on the right edge, USE near the fixed machine gun.
Desktop test: arrows move, right mouse drag looks, SPACE fires, keys 1-4 switch weapons, E = use.

Levels: 1 infantry/grenades - 2 RPG + concrete bunkers - 3 fixed MG + first tank (hit the RED weak spot on top of the turret with the RPG; hide behind walls from tank fire) - 4 bunker chain + tank - 5 snipers (sniper rifle) + two tanks + bunkers.
Enemies show a red "!" right before they shoot. Health regenerates after a few seconds without damage. Checkpoints give a little ammo.
